
		<form class="form-horizontal panel panel-default">
			<div class="panel-body">
				<div class="form-group form-group-sm">
					<label class="col-sm-2 control-label">News Image</label>
					<div class="col-sm-10">
						<input type="file" name="image" class="form-control" >
					</div>
				</div>
				<div class="form-group form-group-sm">
					<label class="col-sm-2 control-label">News Title</label>
					<div class="col-sm-10">
						<input type="text" name="title" class="form-control" placeholder="News Title" aria-describedby="Process">
					</div>
				</div>
				
				<div class="col-sm-2">
					<input type="submit" class="btn btn-info" value="Submit"/>
				</div>
			</div>
		</form>
	