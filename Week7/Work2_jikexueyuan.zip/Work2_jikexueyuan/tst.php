
<!DOCTYPE html>
<html>
	<head>
		<title>fdf</title>
		<style>
			/*.banner { position: relative; overflow: auto; }
    .banner li { list-style: none; }
        .banner ul li { float: left; }*/
		</style>
	</head>
	<body>
		<div> dasfasdf</div>
		<div class="banner">
		    <ul>
		        <li>This is a slide.</li>
		        <li>This is another slide.</li>
		        <li>This is a final slide.</li>
		    </ul>
		</div>
		
		
		<script src="//code.jquery.com/jquery-latest.min.js"></script>
		<script src="js/tst.js"></script>
		<script>
			$(function() {
			    $('.banner').unslider();
			    console.log(123)
			});
		</script>
	</body>
</html>